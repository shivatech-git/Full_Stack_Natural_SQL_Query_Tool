"use client";

export interface HistoryEntry {
  question: string;
  sql: string;
  resultCount: number;
  timestamp: Date;
}

interface QueryHistoryProps {
  history: HistoryEntry[];
  onSelect: (entry: HistoryEntry) => void;
}

export default function QueryHistory({ history, onSelect }: QueryHistoryProps) {
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div>
      <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-3">
        Query History
      </h3>

      <div className="space-y-2">
        {history.slice(0, 8).map((entry, i) => (
          <button
            key={i}
            onClick={() => onSelect(entry)}
            className="w-full text-left bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.06)] rounded-lg px-4 py-3 transition-all hover:border-[rgba(99,102,241,0.2)] group"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0 flex-1">
                <p className="text-sm text-slate-300 group-hover:text-slate-100 transition-colors truncate">
                  {entry.question}
                </p>
                <p className="text-[11px] text-slate-600 font-mono mt-1 truncate">
                  {entry.sql.length > 100
                    ? entry.sql.slice(0, 100) + "..."
                    : entry.sql}
                </p>
              </div>
              <div className="flex flex-col items-end gap-1 shrink-0">
                <span className="text-[11px] text-slate-500">
                  {entry.resultCount} rows
                </span>
                <span className="text-[10px] text-slate-600">
                  {formatTime(entry.timestamp)}
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>

      {history.length > 8 && (
        <p className="text-xs text-slate-600 mt-3 text-center">
          + {history.length - 8} more queries
        </p>
      )}
    </div>
  );
}
