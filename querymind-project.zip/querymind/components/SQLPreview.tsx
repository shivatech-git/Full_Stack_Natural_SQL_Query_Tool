"use client";

import { useState } from "react";

interface SQLPreviewProps {
  sql: string;
  executionTime: number | null;
}

// ─── SQL Syntax Highlighter ──────────────────────────────────────────────────
function highlightSQL(sql: string): string {
  // Order matters: strings first (to avoid highlighting keywords inside strings)
  let result = sql;

  // Highlight strings (single-quoted)
  result = result.replace(
    /('[^']*')/g,
    '<span class="sql-string">$1</span>'
  );

  // Highlight keywords
  const keywords =
    /\b(SELECT|FROM|WHERE|JOIN|LEFT|RIGHT|INNER|OUTER|FULL|CROSS|ON|GROUP\s+BY|ORDER\s+BY|HAVING|LIMIT|OFFSET|AS|AND|OR|IN|NOT|LIKE|ILIKE|BETWEEN|IS|NULL|DISTINCT|CASE|WHEN|THEN|ELSE|END|ASC|DESC|UNION|ALL|EXISTS|ANY|SOME|TRUE|FALSE|COALESCE|NULLIF|CAST)\b/gi;
  result = result.replace(keywords, '<span class="sql-keyword">$1</span>');

  // Highlight functions
  const functions =
    /\b(COUNT|SUM|AVG|MAX|MIN|ROUND|UPPER|LOWER|TRIM|LENGTH|SUBSTRING|CONCAT|DATE_TRUNC|EXTRACT|NOW|CURRENT_DATE|CURRENT_TIMESTAMP|TO_CHAR|TO_DATE)\b/gi;
  result = result.replace(functions, '<span class="sql-function">$1</span>');

  // Highlight numbers (not inside already-highlighted spans)
  result = result.replace(
    /(?<![">])\b(\d+\.?\d*)\b/g,
    '<span class="sql-number">$1</span>'
  );

  return result;
}

export default function SQLPreview({ sql, executionTime }: SQLPreviewProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(sql);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="rounded-xl p-5 border"
      style={{
        background: "rgba(15,23,42,0.8)",
        borderColor: "var(--border-subtle)",
      }}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-[var(--accent-light)] uppercase tracking-wider">
            Generated SQL
          </span>
          {executionTime !== null && (
            <span className="text-xs text-slate-500">
              {executionTime}ms
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-[var(--success)] bg-[rgba(52,211,153,0.1)] px-2.5 py-1 rounded-full">
            ✓ Read-only
          </span>
          <button
            onClick={handleCopy}
            className="text-[11px] text-slate-400 hover:text-white bg-[rgba(255,255,255,0.04)] hover:bg-[rgba(255,255,255,0.08)] px-2.5 py-1 rounded-full transition-all"
          >
            {copied ? "✓ Copied" : "⧉ Copy"}
          </button>
        </div>
      </div>

      <pre
        className="font-mono text-[13px] leading-relaxed text-slate-300 whitespace-pre-wrap break-words m-0"
        dangerouslySetInnerHTML={{ __html: highlightSQL(sql) }}
      />
    </div>
  );
}
