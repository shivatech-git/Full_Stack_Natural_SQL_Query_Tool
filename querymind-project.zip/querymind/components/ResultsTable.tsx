"use client";

import { useState, useMemo } from "react";

interface ResultsTableProps {
  rows: Record<string, unknown>[];
}

type SortDirection = "asc" | "desc" | null;

export default function ResultsTable({ rows }: ResultsTableProps) {
  const [sortCol, setSortCol] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<SortDirection>(null);
  const [page, setPage] = useState(0);
  const pageSize = 25;

  const columns = useMemo(() => {
    if (!rows.length) return [];
    return Object.keys(rows[0]);
  }, [rows]);

  // ── Sorting ──────────────────────────────────────────────────────────────
  const sortedRows = useMemo(() => {
    if (!sortCol || !sortDir) return rows;
    return [...rows].sort((a, b) => {
      const va = a[sortCol];
      const vb = b[sortCol];
      const na = Number(va);
      const nb = Number(vb);

      if (!isNaN(na) && !isNaN(nb)) {
        return sortDir === "desc" ? nb - na : na - nb;
      }
      const sa = String(va ?? "");
      const sb = String(vb ?? "");
      return sortDir === "desc"
        ? sb.localeCompare(sa)
        : sa.localeCompare(sb);
    });
  }, [rows, sortCol, sortDir]);

  // ── Pagination ───────────────────────────────────────────────────────────
  const totalPages = Math.ceil(sortedRows.length / pageSize);
  const pagedRows = sortedRows.slice(page * pageSize, (page + 1) * pageSize);

  const handleSort = (col: string) => {
    if (sortCol === col) {
      if (sortDir === "asc") setSortDir("desc");
      else if (sortDir === "desc") {
        setSortCol(null);
        setSortDir(null);
      }
    } else {
      setSortCol(col);
      setSortDir("asc");
    }
    setPage(0);
  };

  const getSortIcon = (col: string) => {
    if (sortCol !== col) return "↕";
    if (sortDir === "asc") return "↑";
    return "↓";
  };

  // ── Format cell values ───────────────────────────────────────────────────
  const formatValue = (val: unknown): string => {
    if (val === null || val === undefined) return "—";
    if (typeof val === "number") {
      return val % 1 !== 0 ? val.toFixed(2) : val.toString();
    }
    return String(val);
  };

  const isNumeric = (col: string): boolean => {
    return rows.every(
      (r) => r[col] === null || r[col] === undefined || !isNaN(Number(r[col]))
    );
  };

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr>
              {columns.map((col) => (
                <th
                  key={col}
                  onClick={() => handleSort(col)}
                  className="text-left px-4 py-2.5 text-[11px] font-semibold text-slate-500 uppercase tracking-wider border-b border-[rgba(255,255,255,0.06)] cursor-pointer hover:text-slate-300 transition-colors select-none font-mono"
                >
                  <span className="flex items-center gap-1.5">
                    {col.replace(/^\w+\./, "")}
                    <span className="text-[10px] opacity-50">
                      {getSortIcon(col)}
                    </span>
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pagedRows.map((row, i) => (
              <tr
                key={i}
                className={`${
                  i % 2 === 0
                    ? "bg-transparent"
                    : "bg-[rgba(255,255,255,0.015)]"
                } hover:bg-[rgba(99,102,241,0.04)] transition-colors`}
              >
                {columns.map((col) => (
                  <td
                    key={col}
                    className={`px-4 py-2.5 text-[13px] border-b border-[rgba(255,255,255,0.03)] ${
                      isNumeric(col)
                        ? "font-mono text-slate-300"
                        : "text-slate-300"
                    }`}
                  >
                    {formatValue(row[col])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-[rgba(255,255,255,0.06)]">
          <span className="text-xs text-slate-500">
            Showing {page * pageSize + 1}–
            {Math.min((page + 1) * pageSize, sortedRows.length)} of{" "}
            {sortedRows.length} rows
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
              className="px-3 py-1.5 text-xs rounded-md bg-[rgba(255,255,255,0.04)] text-slate-400 disabled:opacity-30 hover:bg-[rgba(255,255,255,0.08)] transition-all"
            >
              ← Prev
            </button>
            <span className="text-xs text-slate-500">
              {page + 1} / {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page >= totalPages - 1}
              className="px-3 py-1.5 text-xs rounded-md bg-[rgba(255,255,255,0.04)] text-slate-400 disabled:opacity-30 hover:bg-[rgba(255,255,255,0.08)] transition-all"
            >
              Next →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
