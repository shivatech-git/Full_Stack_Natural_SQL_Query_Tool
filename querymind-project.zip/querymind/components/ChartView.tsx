"use client";

import { useMemo, useState } from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

interface ChartViewProps {
  data: Record<string, unknown>[];
}

type ChartType = "bar" | "line" | "pie";

interface ChartConfig {
  type: ChartType;
  xKey: string;
  yKeys: string[];
  labelKey?: string;
  valueKey?: string;
}

const COLORS = [
  "#6366f1",
  "#f59e0b",
  "#10b981",
  "#ef4444",
  "#8b5cf6",
  "#ec4899",
  "#06b6d4",
  "#f97316",
];

const TOOLTIP_STYLE = {
  background: "#1e293b",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: 8,
  color: "#e2e8f0",
  fontSize: 13,
};

function suggestChart(data: Record<string, unknown>[]): ChartConfig | null {
  if (!data || data.length === 0) return null;

  const keys = Object.keys(data[0]);
  if (keys.length < 2) return null;

  const numericKeys = keys.filter((k) =>
    data.every((r) => r[k] === null || !isNaN(Number(r[k])))
  );
  const stringKeys = keys.filter((k) => !numericKeys.includes(k));

  if (data.length === 1) return null;

  if (stringKeys.length >= 1 && numericKeys.length >= 1) {
    if (data.length <= 6 && numericKeys.length === 1) {
      return {
        type: "pie",
        xKey: stringKeys[0],
        yKeys: numericKeys,
        labelKey: stringKeys[0],
        valueKey: numericKeys[0],
      };
    }
    return { type: "bar", xKey: stringKeys[0], yKeys: numericKeys.slice(0, 3) };
  }

  if (numericKeys.length >= 2) {
    return { type: "line", xKey: keys[0], yKeys: numericKeys.slice(1, 4) };
  }

  return null;
}

export default function ChartView({ data }: ChartViewProps) {
  const suggestion = useMemo(() => suggestChart(data), [data]);
  const [chartType, setChartType] = useState<ChartType | null>(null);

  const activeType = chartType || suggestion?.type || "bar";
  const config = suggestion;

  if (!config) {
    return (
      <div className="text-center py-12 text-slate-400 text-sm">
        <p>This data isn&apos;t suitable for charting.</p>
        <p className="text-slate-500 text-xs mt-1">
          Try a query that returns categories with numeric values.
        </p>
      </div>
    );
  }

  // Prepare data — ensure numeric values are actual numbers
  const chartData = data.map((row) => {
    const cleaned: Record<string, unknown> = {};
    for (const key of Object.keys(row)) {
      const val = row[key];
      if (config.yKeys.includes(key) || key === config.valueKey) {
        cleaned[key] = Number(val) || 0;
      } else {
        cleaned[key] = val;
      }
    }
    return cleaned;
  });

  return (
    <div>
      {/* Chart type selector */}
      <div className="flex items-center gap-2 mb-4">
        <span className="text-xs text-slate-500 mr-1">Chart type:</span>
        {(["bar", "line", "pie"] as ChartType[]).map((type) => (
          <button
            key={type}
            onClick={() => setChartType(type)}
            className={`px-3 py-1 text-xs rounded-md transition-all ${
              activeType === type
                ? "bg-[rgba(99,102,241,0.15)] text-[var(--accent-light)] border border-[var(--border-accent)]"
                : "bg-[rgba(255,255,255,0.03)] text-slate-500 border border-transparent hover:text-slate-300"
            }`}
          >
            {type === "bar" ? "▥ Bar" : type === "line" ? "⌇ Line" : "◕ Pie"}
          </button>
        ))}
      </div>

      {/* Charts */}
      {activeType === "bar" && (
        <ResponsiveContainer width="100%" height={360}>
          <BarChart
            data={chartData}
            margin={{ top: 16, right: 24, left: 0, bottom: 8 }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(255,255,255,0.06)"
            />
            <XAxis
              dataKey={config.xKey}
              tick={{ fill: "#94a3b8", fontSize: 12 }}
              axisLine={{ stroke: "rgba(255,255,255,0.1)" }}
            />
            <YAxis
              tick={{ fill: "#94a3b8", fontSize: 12 }}
              axisLine={{ stroke: "rgba(255,255,255,0.1)" }}
            />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Legend />
            {config.yKeys.map((k, i) => (
              <Bar
                key={k}
                dataKey={k}
                fill={COLORS[i % COLORS.length]}
                radius={[4, 4, 0, 0]}
              />
            ))}
          </BarChart>
        </ResponsiveContainer>
      )}

      {activeType === "line" && (
        <ResponsiveContainer width="100%" height={360}>
          <LineChart
            data={chartData}
            margin={{ top: 16, right: 24, left: 0, bottom: 8 }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="rgba(255,255,255,0.06)"
            />
            <XAxis
              dataKey={config.xKey}
              tick={{ fill: "#94a3b8", fontSize: 12 }}
              axisLine={{ stroke: "rgba(255,255,255,0.1)" }}
            />
            <YAxis
              tick={{ fill: "#94a3b8", fontSize: 12 }}
              axisLine={{ stroke: "rgba(255,255,255,0.1)" }}
            />
            <Tooltip contentStyle={TOOLTIP_STYLE} />
            <Legend />
            {config.yKeys.map((k, i) => (
              <Line
                key={k}
                type="monotone"
                dataKey={k}
                stroke={COLORS[i % COLORS.length]}
                strokeWidth={2}
                dot={{ fill: COLORS[i], r: 4 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      )}

      {activeType === "pie" && config.labelKey && config.valueKey && (
        <ResponsiveContainer width="100%" height={360}>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              outerRadius={130}
              dataKey={config.valueKey}
              nameKey={config.labelKey}
              label={({ name, percent }) =>
                `${name}: ${(percent * 100).toFixed(0)}%`
              }
            >
              {chartData.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip contentStyle={TOOLTIP_STYLE} />
          </PieChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
