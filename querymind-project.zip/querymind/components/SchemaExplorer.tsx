"use client";

import { useState, useEffect } from "react";

// ─── Fallback schema for when the API isn't available ────────────────────────
const FALLBACK_SCHEMA = {
  products: {
    columns: [
      { name: "id", type: "integer", pk: true },
      { name: "name", type: "varchar(255)" },
      { name: "category", type: "varchar(100)" },
      { name: "price", type: "decimal(10,2)" },
      { name: "stock", type: "integer" },
      { name: "rating", type: "decimal(2,1)" },
      { name: "created_at", type: "timestamp" },
    ],
    rowCount: 15,
  },
  customers: {
    columns: [
      { name: "id", type: "integer", pk: true },
      { name: "name", type: "varchar(255)" },
      { name: "email", type: "varchar(255)" },
      { name: "city", type: "varchar(100)" },
      { name: "joined", type: "date" },
      { name: "total_spent", type: "decimal(10,2)" },
    ],
    rowCount: 12,
  },
  orders: {
    columns: [
      { name: "id", type: "integer", pk: true },
      { name: "product_id", type: "integer", fk: "products.id" },
      { name: "customer_id", type: "integer", fk: "customers.id" },
      { name: "quantity", type: "integer" },
      { name: "total", type: "decimal(10,2)" },
      { name: "order_date", type: "date" },
      { name: "status", type: "varchar(20)" },
    ],
    rowCount: 20,
  },
};

interface ColumnDef {
  name: string;
  type: string;
  pk?: boolean;
  fk?: string;
}

export default function SchemaExplorer() {
  const [expandedTable, setExpandedTable] = useState<string | null>(null);
  const schema = FALLBACK_SCHEMA;

  const toggleTable = (table: string) => {
    setExpandedTable(expandedTable === table ? null : table);
  };

  return (
    <div
      className="rounded-xl p-5 border"
      style={{
        background: "var(--bg-card)",
        borderColor: "var(--border-subtle)",
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xs font-semibold text-[var(--accent-light)] uppercase tracking-wider">
          Database Schema
        </h2>
        <span className="text-[11px] text-slate-500">
          {Object.keys(schema).length} tables
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {Object.entries(schema).map(([tableName, tableInfo]) => (
          <div
            key={tableName}
            className="bg-[rgba(255,255,255,0.02)] border border-[rgba(255,255,255,0.06)] rounded-lg overflow-hidden transition-all hover:border-[rgba(99,102,241,0.15)]"
          >
            {/* Table Header */}
            <button
              onClick={() => toggleTable(tableName)}
              className="w-full flex items-center justify-between px-4 py-3 text-left"
            >
              <div className="flex items-center gap-2">
                <span className="text-[var(--accent-light)] text-sm">⊞</span>
                <span className="font-semibold text-sm text-slate-200">
                  {tableName}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-500">
                  {tableInfo.rowCount} rows
                </span>
                <span className="text-slate-500 text-xs">
                  {expandedTable === tableName ? "▾" : "▸"}
                </span>
              </div>
            </button>

            {/* Column Chips (always visible) */}
            <div className="px-4 pb-3 flex flex-wrap gap-1.5">
              {tableInfo.columns.map((col: ColumnDef) => (
                <span
                  key={col.name}
                  className={`text-[11px] px-2 py-0.5 rounded font-mono ${
                    col.pk
                      ? "bg-[rgba(99,102,241,0.15)] text-[var(--accent-light)] border border-[rgba(99,102,241,0.2)]"
                      : col.fk
                      ? "bg-[rgba(245,158,11,0.1)] text-amber-400 border border-[rgba(245,158,11,0.15)]"
                      : "bg-[rgba(255,255,255,0.04)] text-slate-400 border border-[rgba(255,255,255,0.06)]"
                  }`}
                >
                  {col.pk && "🔑 "}
                  {col.fk && "→ "}
                  {col.name}
                </span>
              ))}
            </div>

            {/* Expanded Detail */}
            {expandedTable === tableName && (
              <div className="px-4 pb-3 border-t border-[rgba(255,255,255,0.04)] pt-3 animate-fade-in">
                <table className="w-full">
                  <thead>
                    <tr>
                      <th className="text-[10px] text-slate-500 text-left pb-1 font-medium">
                        COLUMN
                      </th>
                      <th className="text-[10px] text-slate-500 text-left pb-1 font-medium">
                        TYPE
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {tableInfo.columns.map((col: ColumnDef) => (
                      <tr key={col.name}>
                        <td className="text-xs text-slate-300 py-0.5 font-mono">
                          {col.name}
                          {col.pk && (
                            <span className="text-[10px] text-[var(--accent-light)] ml-1">
                              PK
                            </span>
                          )}
                          {col.fk && (
                            <span className="text-[10px] text-amber-400 ml-1">
                              FK→{col.fk}
                            </span>
                          )}
                        </td>
                        <td className="text-xs text-slate-500 py-0.5 font-mono">
                          {col.type}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 mt-4 pt-3 border-t border-[rgba(255,255,255,0.04)]">
        <span className="text-[10px] text-slate-500 flex items-center gap-1">
          <span className="w-2 h-2 rounded-sm bg-[rgba(99,102,241,0.3)]" />
          Primary Key
        </span>
        <span className="text-[10px] text-slate-500 flex items-center gap-1">
          <span className="w-2 h-2 rounded-sm bg-[rgba(245,158,11,0.3)]" />
          Foreign Key
        </span>
        <span className="text-[10px] text-slate-500 flex items-center gap-1">
          <span className="w-2 h-2 rounded-sm bg-[rgba(255,255,255,0.08)]" />
          Column
        </span>
      </div>
    </div>
  );
}
