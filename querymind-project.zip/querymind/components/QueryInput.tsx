"use client";

import { useRef, useEffect } from "react";

interface QueryInputProps {
  query: string;
  setQuery: (q: string) => void;
  onSubmit: () => void;
  loading: boolean;
}

export default function QueryInput({
  query,
  setQuery,
  onSubmit,
  loading,
}: QueryInputProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !loading) {
      onSubmit();
    }
  };

  return (
    <div
      className="flex items-center rounded-2xl p-1.5 transition-all border"
      style={{
        background: "var(--bg-card)",
        borderColor: "var(--border-subtle)",
        boxShadow: "0 0 40px rgba(99,102,241,0.06)",
      }}
    >
      <input
        ref={inputRef}
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Ask a question about your data..."
        className="flex-1 bg-transparent border-none text-[var(--text-primary)] text-[15px] px-5 py-3.5 outline-none placeholder:text-slate-600"
      />
      <button
        onClick={onSubmit}
        disabled={loading || !query.trim()}
        className="px-6 py-3 rounded-xl text-sm font-semibold text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        style={{
          background: loading
            ? "rgba(99,102,241,0.3)"
            : "linear-gradient(135deg, #6366f1, #7c3aed)",
          cursor: loading ? "not-allowed" : "pointer",
        }}
      >
        {loading ? "⟳ Thinking..." : "Run ↵"}
      </button>
    </div>
  );
}
