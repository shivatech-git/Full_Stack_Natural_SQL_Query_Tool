# ⚡ QueryMind — Natural Language SQL Query Tool

Ask questions about your data in plain English. QueryMind translates your questions into SQL, executes them safely, and visualizes the results — all powered by Claude AI.

![Next.js](https://img.shields.io/badge/Next.js-14-black?logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5.5-blue?logo=typescript)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16-336791?logo=postgresql)
![Claude AI](https://img.shields.io/badge/Claude_AI-Sonnet_4-blueviolet)

---

## 🎯 What It Does

1. **You type a question** → "What are the top 5 products by revenue?"
2. **Claude AI generates SQL** → `SELECT p.name, SUM(o.total) ... ORDER BY revenue DESC LIMIT 5`
3. **SQL is validated** → Read-only enforcement, injection prevention, timeout limits
4. **Query executes** → Against a real PostgreSQL database
5. **Results render** → As a sortable table AND auto-suggested chart

## 🏗️ Architecture

```
┌──────────────────────────────────────────────────┐
│  Frontend (Next.js + React + TypeScript)         │
│  ┌────────────┐ ┌──────────┐ ┌───────────────┐  │
│  │ QueryInput │ │ SQLPreview│ │ ResultsTable  │  │
│  └─────┬──────┘ └──────────┘ ├───────────────┤  │
│        │                      │  ChartView    │  │
│        ▼                      └───────────────┘  │
│  ┌─────────────────────┐  ┌──────────────────┐   │
│  │  SchemaExplorer     │  │  QueryHistory    │   │
│  └─────────────────────┘  └──────────────────┘   │
└──────────────────┬───────────────────────────────┘
                   │ API Routes
         ┌─────────┴──────────┐
         ▼                    ▼
┌─────────────────┐  ┌────────────────┐
│ /api/generate-sql│  │ /api/execute-sql│
│                 │  │                │
│ • Rate limiting │  │ • SQL validation│
│ • Schema fetch  │  │ • Injection check│
│ • Prompt build  │  │ • Timeout guard │
│ • Claude API    │  │ • Row limiter   │
└────────┬────────┘  └───────┬────────┘
         │                   │
         ▼                   ▼
┌─────────────────┐  ┌────────────────┐
│  Claude API     │  │  PostgreSQL    │
│  (Sonnet 4)     │  │  Database      │
└─────────────────┘  └────────────────┘
```

## 🔐 Security Features

This project demonstrates production-level security thinking:

- **Read-only enforcement** — Only SELECT statements are allowed. INSERT, UPDATE, DELETE, DROP, ALTER are all blocked at the validation layer.
- **SQL injection prevention** — AI-generated SQL is validated against blocked keywords and patterns before execution.
- **Statement stacking blocked** — Multiple statements separated by semicolons are rejected.
- **Query timeouts** — 10-second maximum execution time prevents runaway queries.
- **Row limits** — Maximum 500 rows returned to prevent memory issues.
- **Rate limiting** — 20 requests/minute per IP to prevent API abuse.
- **Server-side API key** — The Anthropic API key never reaches the browser.

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL 14+ (local or hosted — [Neon](https://neon.tech), [Supabase](https://supabase.com), or [Railway](https://railway.app) all work)
- Anthropic API key ([get one here](https://console.anthropic.com))

### Setup

```bash
# 1. Clone the repo
git clone https://github.com/yourusername/querymind.git
cd querymind

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env.local
# Edit .env.local with your API key and database URL

# 4. Seed the database with demo data
npm run db:seed

# 5. Start the dev server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and start asking questions!

### Example Queries to Try

- "Show me the top 5 most expensive products"
- "What is the total revenue by product category?"
- "Which customers have spent more than $200?"
- "How many orders are in each status?"
- "What is the average order value per customer?"
- "List all electronics sorted by rating descending"

## 📁 Project Structure

```
querymind/
├── app/
│   ├── layout.tsx                 → Root layout with metadata
│   ├── page.tsx                   → Main page — orchestrates all components
│   ├── globals.css                → Theme, animations, syntax highlighting
│   └── api/
│       ├── generate-sql/route.ts  → Claude API integration + rate limiting
│       └── execute-sql/route.ts   → SQL validation + safe execution
├── components/
│   ├── QueryInput.tsx             → Natural language input bar
│   ├── SQLPreview.tsx             → Syntax-highlighted SQL display
│   ├── ResultsTable.tsx           → Sortable, paginated results table
│   ├── ChartView.tsx              → Auto-suggested Bar/Line/Pie charts
│   ├── SchemaExplorer.tsx         → Interactive database schema browser
│   └── QueryHistory.tsx           → Clickable history of past queries
├── lib/
│   ├── database.ts                → PostgreSQL connection pool + schema reader
│   ├── sqlValidator.ts            → SQL safety validation + row limits
│   ├── promptBuilder.ts           → Claude prompt construction
│   └── seed.ts                    → Database seeding script
├── .env.example                   → Environment variable template
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

## 🛠️ Tech Stack

| Layer       | Technology                          | Why                                          |
|-------------|--------------------------------------|----------------------------------------------|
| Framework   | Next.js 14 (App Router)              | Full-stack React with API routes              |
| Language    | TypeScript                           | Type safety across frontend + backend         |
| AI          | Claude Sonnet 4 (Anthropic API)      | Best-in-class SQL generation                  |
| Database    | PostgreSQL                           | Industry standard relational database         |
| Styling     | Tailwind CSS                         | Utility-first, fast iteration                 |
| Charts      | Recharts                             | Composable React chart components             |
| DB Client   | node-pg                              | Direct PostgreSQL driver (no ORM overhead)    |

## 🧠 Key Design Decisions

1. **No ORM** — Used raw SQL with `node-pg` to demonstrate SQL knowledge and keep the abstraction layer thin. In production, you might add Prisma for migrations.

2. **Separate API routes** — `generate-sql` and `execute-sql` are independent so you can swap the AI provider without touching the execution logic, and vice versa.

3. **Prompt engineering in its own file** — `promptBuilder.ts` isolates prompt logic for easy iteration and testing. The system prompt enforces strict SQL-only output.

4. **Client-side chart suggestion** — The chart type is inferred from the data shape (categorical + numeric = bar, few categories + one metric = pie, etc.) rather than asking the AI.

5. **Conversation history** — The last 3 queries are sent as context so you can ask follow-up questions like "now group that by month."

## 📈 Future Improvements

- [ ] Add authentication (NextAuth.js)
- [ ] Support multiple database connections
- [ ] Stream Claude's response for perceived speed
- [ ] Add "explain this query" feature
- [ ] Export results to CSV
- [ ] Add cost tracking per query
- [ ] Deploy to Vercel + Neon

## 📄 License

MIT — use freely for your portfolio and projects.
