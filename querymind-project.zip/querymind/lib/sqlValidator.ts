// ─── SQL Validator ───────────────────────────────────────────────────────────
// Validates AI-generated SQL before execution to prevent destructive operations.
// This is a CRITICAL security layer — never execute unvalidated SQL.

export interface ValidationResult {
  valid: boolean;
  error?: string;
  sanitizedSQL?: string;
}

// Keywords that indicate destructive or unauthorized operations
const BLOCKED_KEYWORDS = [
  "INSERT",
  "UPDATE",
  "DELETE",
  "DROP",
  "ALTER",
  "CREATE",
  "TRUNCATE",
  "GRANT",
  "REVOKE",
  "EXEC",
  "EXECUTE",
  "COPY",
  "pg_",
  "information_schema",  // prevent schema snooping beyond our getter
  "pg_catalog",
];

// Patterns that suggest SQL injection or malicious intent
const BLOCKED_PATTERNS = [
  /;\s*\w/i,           // multiple statements (statement stacking)
  /--/,                 // SQL comments (could hide malicious code)
  /\/\*/,               // block comments
  /xp_/i,              // extended stored procedures (SQL Server)
  /sp_/i,              // system stored procedures
  /LOAD_FILE/i,        // file system access
  /INTO\s+OUTFILE/i,   // file writing
  /INTO\s+DUMPFILE/i,  // file writing
  /BENCHMARK\s*\(/i,   // timing attacks
  /SLEEP\s*\(/i,       // timing attacks
  /WAITFOR/i,          // timing attacks (SQL Server)
];

export function validateSQL(sql: string): ValidationResult {
  if (!sql || typeof sql !== "string") {
    return { valid: false, error: "No SQL query provided." };
  }

  // Clean up the SQL
  const cleaned = sql
    .trim()
    .replace(/```sql|```/g, "")  // remove markdown fences
    .replace(/^\s*\n/gm, "")     // remove blank lines
    .trim();

  if (!cleaned) {
    return { valid: false, error: "Empty SQL query." };
  }

  // Must start with SELECT
  if (!/^\s*SELECT/i.test(cleaned)) {
    return {
      valid: false,
      error: "Only SELECT queries are allowed. The query must start with SELECT.",
    };
  }

  // Check for blocked keywords
  for (const keyword of BLOCKED_KEYWORDS) {
    // Use word boundary regex to avoid false positives
    // e.g., "category" shouldn't match "ALTER"
    const regex = new RegExp(`\\b${keyword}\\b`, "i");
    if (regex.test(cleaned)) {
      return {
        valid: false,
        error: `Blocked operation detected: "${keyword}". Only read-only SELECT queries are permitted.`,
      };
    }
  }

  // Check for blocked patterns
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(cleaned)) {
      return {
        valid: false,
        error: "Query contains a potentially unsafe pattern and has been blocked.",
      };
    }
  }

  // Remove trailing semicolon (we add our own when executing)
  const sanitized = cleaned.replace(/;\s*$/, "").trim();

  return { valid: true, sanitizedSQL: sanitized };
}

// ─── Query Timeout Wrapper ───────────────────────────────────────────────────
// Wraps the query execution with a timeout to prevent long-running queries
// from consuming resources.

export const QUERY_TIMEOUT_MS = 10_000; // 10 seconds max

export const MAX_ROWS = 500; // Maximum rows returned to the client

// Wrap a SQL query with a row limit if not already present
export function addRowLimit(sql: string, limit: number = MAX_ROWS): string {
  if (/LIMIT\s+\d+/i.test(sql)) {
    return sql; // already has a LIMIT
  }
  return `${sql} LIMIT ${limit}`;
}
