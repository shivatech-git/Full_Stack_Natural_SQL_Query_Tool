// ─── Database Seed Script ────────────────────────────────────────────────────
// Run with: npm run db:seed
// Creates tables and populates them with demo e-commerce data.

import { Pool } from "pg";
import "dotenv/config";

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function seed() {
  const client = await pool.connect();

  try {
    console.log("🗄️  Dropping existing tables...");
    await client.query(`
      DROP TABLE IF EXISTS orders CASCADE;
      DROP TABLE IF EXISTS customers CASCADE;
      DROP TABLE IF EXISTS products CASCADE;
    `);

    console.log("📦 Creating products table...");
    await client.query(`
      CREATE TABLE products (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        price DECIMAL(10,2) NOT NULL,
        stock INTEGER NOT NULL DEFAULT 0,
        rating DECIMAL(2,1) CHECK (rating >= 0 AND rating <= 5),
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);

    console.log("👥 Creating customers table...");
    await client.query(`
      CREATE TABLE customers (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        city VARCHAR(100) NOT NULL,
        joined DATE NOT NULL,
        total_spent DECIMAL(10,2) DEFAULT 0
      );
    `);

    console.log("🛒 Creating orders table...");
    await client.query(`
      CREATE TABLE orders (
        id SERIAL PRIMARY KEY,
        product_id INTEGER REFERENCES products(id),
        customer_id INTEGER REFERENCES customers(id),
        quantity INTEGER NOT NULL CHECK (quantity > 0),
        total DECIMAL(10,2) NOT NULL,
        order_date DATE NOT NULL,
        status VARCHAR(20) CHECK (status IN ('processing', 'shipped', 'delivered', 'cancelled'))
      );
    `);

    console.log("📦 Inserting products...");
    await client.query(`
      INSERT INTO products (name, category, price, stock, rating) VALUES
        ('Wireless Headphones', 'Electronics', 79.99, 234, 4.5),
        ('Mechanical Keyboard', 'Electronics', 129.99, 156, 4.7),
        ('Running Shoes', 'Sports', 119.99, 89, 4.3),
        ('Yoga Mat', 'Sports', 29.99, 412, 4.1),
        ('Coffee Maker', 'Home', 89.99, 67, 4.6),
        ('Desk Lamp', 'Home', 44.99, 198, 4.2),
        ('Bluetooth Speaker', 'Electronics', 59.99, 321, 4.4),
        ('Water Bottle', 'Sports', 24.99, 567, 4.0),
        ('Air Purifier', 'Home', 199.99, 43, 4.8),
        ('Smartwatch', 'Electronics', 249.99, 112, 4.6),
        ('Fitness Tracker', 'Electronics', 149.99, 203, 4.3),
        ('Standing Desk', 'Home', 399.99, 34, 4.7),
        ('Protein Powder', 'Sports', 39.99, 289, 4.2),
        ('Noise Cancelling Earbuds', 'Electronics', 199.99, 178, 4.6),
        ('Dutch Oven', 'Home', 69.99, 95, 4.5);
    `);

    console.log("👥 Inserting customers...");
    await client.query(`
      INSERT INTO customers (name, email, city, joined, total_spent) VALUES
        ('Alice Johnson', 'alice@email.com', 'New York', '2024-06-15', 419.96),
        ('Bob Smith', 'bob@email.com', 'Los Angeles', '2024-07-20', 219.95),
        ('Carol White', 'carol@email.com', 'Chicago', '2024-08-10', 179.98),
        ('David Brown', 'david@email.com', 'Houston', '2024-09-05', 369.97),
        ('Eve Davis', 'eve@email.com', 'Phoenix', '2024-10-12', 499.98),
        ('Frank Miller', 'frank@email.com', 'New York', '2024-11-01', 179.97),
        ('Grace Lee', 'grace@email.com', 'San Francisco', '2024-12-15', 59.98),
        ('Henry Wilson', 'henry@email.com', 'Chicago', '2025-01-08', 199.99),
        ('Ivy Chen', 'ivy@email.com', 'Los Angeles', '2025-01-20', 44.99),
        ('Jack Taylor', 'jack@email.com', 'Houston', '2025-02-14', 79.99),
        ('Karen Adams', 'karen@email.com', 'Seattle', '2025-02-28', 329.97),
        ('Leo Martinez', 'leo@email.com', 'Miami', '2025-03-05', 159.98);
    `);

    console.log("🛒 Inserting orders...");
    await client.query(`
      INSERT INTO orders (product_id, customer_id, quantity, total, order_date, status) VALUES
        (1, 1, 2, 159.98, '2025-01-15', 'delivered'),
        (3, 2, 1, 119.99, '2025-01-18', 'delivered'),
        (5, 3, 1, 89.99, '2025-01-25', 'delivered'),
        (2, 4, 1, 129.99, '2025-02-10', 'delivered'),
        (10, 5, 1, 249.99, '2025-02-14', 'delivered'),
        (7, 6, 3, 179.97, '2025-02-20', 'delivered'),
        (4, 7, 2, 59.98, '2025-03-01', 'shipped'),
        (9, 8, 1, 199.99, '2025-03-05', 'shipped'),
        (6, 9, 1, 44.99, '2025-03-08', 'delivered'),
        (1, 10, 1, 79.99, '2025-03-10', 'processing'),
        (2, 1, 2, 259.98, '2025-03-12', 'shipped'),
        (8, 2, 4, 99.96, '2025-03-14', 'delivered'),
        (5, 3, 1, 89.99, '2025-03-15', 'processing'),
        (3, 4, 2, 239.98, '2025-02-28', 'delivered'),
        (10, 5, 1, 249.99, '2025-03-15', 'processing'),
        (11, 11, 1, 149.99, '2025-03-01', 'delivered'),
        (12, 11, 1, 399.99, '2025-03-08', 'shipped'),
        (14, 12, 1, 199.99, '2025-03-10', 'delivered'),
        (13, 2, 2, 79.98, '2025-03-12', 'shipped'),
        (15, 6, 1, 69.99, '2025-03-14', 'processing');
    `);

    // Create useful indexes
    console.log("🔍 Creating indexes...");
    await client.query(`
      CREATE INDEX idx_orders_product_id ON orders(product_id);
      CREATE INDEX idx_orders_customer_id ON orders(customer_id);
      CREATE INDEX idx_orders_status ON orders(status);
      CREATE INDEX idx_orders_date ON orders(order_date);
      CREATE INDEX idx_products_category ON products(category);
    `);

    console.log("\n✅ Database seeded successfully!");
    console.log("   → 15 products");
    console.log("   → 12 customers");
    console.log("   → 20 orders");
    console.log("\nYou can now run: npm run dev");
  } catch (error) {
    console.error("❌ Seed failed:", error);
    throw error;
  } finally {
    client.release();
    await pool.end();
  }
}

seed();
