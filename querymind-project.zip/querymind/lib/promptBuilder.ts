// ─── Prompt Builder ──────────────────────────────────────────────────────────
// Constructs optimized prompts for Claude to generate accurate SQL queries.
// Separates prompt logic from API call logic for testability and reuse.

export interface PromptContext {
  schemaText: string;
  userQuestion: string;
  conversationHistory?: { question: string; sql: string }[];
}

// ─── System Prompt ───────────────────────────────────────────────────────────
// Defines Claude's role and strict rules for SQL generation.

export function buildSystemPrompt(): string {
  return `You are an expert SQL query generator for PostgreSQL databases.

Your ONLY job is to convert natural language questions into valid PostgreSQL SELECT queries.

STRICT RULES:
1. Return ONLY the raw SQL query — no explanations, no markdown, no backticks, no comments.
2. Only generate SELECT statements. Never use INSERT, UPDATE, DELETE, DROP, ALTER, or any write operation.
3. Use exact table and column names from the provided schema.
4. Use proper PostgreSQL syntax (e.g., use ILIKE for case-insensitive matching).
5. Always qualify ambiguous column names with table aliases.
6. Use meaningful table aliases (e.g., p for products, o for orders).
7. When aggregating, always include a GROUP BY clause with all non-aggregated columns.
8. For date filtering, use PostgreSQL date functions (DATE_TRUNC, EXTRACT, etc.).
9. Default to ordering results in a useful way (e.g., descending by amount, ascending by name).
10. Limit results to 100 rows unless the user asks for a specific count.

If the question cannot be answered with the given schema, return:
SELECT 'This question cannot be answered with the available tables' AS error`;
}

// ─── User Message ────────────────────────────────────────────────────────────
// Combines schema + question + optional history into the user message.

export function buildUserMessage(context: PromptContext): string {
  let message = `DATABASE SCHEMA:\n${context.schemaText}\n\n`;

  // Include conversation history for follow-up questions
  if (context.conversationHistory && context.conversationHistory.length > 0) {
    message += "PREVIOUS QUERIES (for context on follow-up questions):\n";
    for (const entry of context.conversationHistory.slice(-3)) {
      message += `  Q: "${entry.question}"\n  SQL: ${entry.sql}\n\n`;
    }
  }

  message += `USER QUESTION: "${context.userQuestion}"\n\n`;
  message += `Generate the PostgreSQL SELECT query:`;

  return message;
}

// ─── Full Messages Array ─────────────────────────────────────────────────────
// Returns the complete messages array ready for the Anthropic API call.

export function buildMessages(context: PromptContext) {
  return {
    system: buildSystemPrompt(),
    messages: [
      {
        role: "user" as const,
        content: buildUserMessage(context),
      },
    ],
  };
}
