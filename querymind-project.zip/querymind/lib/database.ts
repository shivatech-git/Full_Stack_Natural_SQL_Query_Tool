import { Pool } from "pg";

// ─── Database Connection Pool ────────────────────────────────────────────────
// Uses a singleton pattern to reuse connections across API routes.
// In development, we attach the pool to `globalThis` to survive hot reloads.

const globalForDb = globalThis as unknown as { pool: Pool | undefined };

export const pool: Pool =
  globalForDb.pool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
  });

if (process.env.NODE_ENV !== "production") {
  globalForDb.pool = pool;
}

// ─── Helper: Run a query ─────────────────────────────────────────────────────
export async function query<T = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<T[]> {
  const client = await pool.connect();
  try {
    const result = await client.query(text, params);
    return result.rows as T[];
  } finally {
    client.release();
  }
}

// ─── Helper: Get database schema ─────────────────────────────────────────────
// Reads table names, column names, types, and constraints from PostgreSQL
// information_schema. This is sent to Claude as context for SQL generation.

export interface ColumnInfo {
  table_name: string;
  column_name: string;
  data_type: string;
  is_nullable: string;
  column_default: string | null;
}

export interface ForeignKey {
  source_table: string;
  source_column: string;
  target_table: string;
  target_column: string;
}

export async function getSchema(): Promise<{
  columns: ColumnInfo[];
  foreignKeys: ForeignKey[];
}> {
  const columns = await query<ColumnInfo>(`
    SELECT table_name, column_name, data_type, is_nullable, column_default
    FROM information_schema.columns
    WHERE table_schema = 'public'
    ORDER BY table_name, ordinal_position
  `);

  const foreignKeys = await query<ForeignKey>(`
    SELECT
      tc.table_name AS source_table,
      kcu.column_name AS source_column,
      ccu.table_name AS target_table,
      ccu.column_name AS target_column
    FROM information_schema.table_constraints AS tc
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
    WHERE tc.constraint_type = 'FOREIGN KEY'
  `);

  return { columns, foreignKeys };
}

// ─── Helper: Format schema as text for the AI prompt ─────────────────────────
export function formatSchemaForPrompt(schema: {
  columns: ColumnInfo[];
  foreignKeys: ForeignKey[];
}): string {
  const tables: Record<string, ColumnInfo[]> = {};

  for (const col of schema.columns) {
    if (!tables[col.table_name]) tables[col.table_name] = [];
    tables[col.table_name].push(col);
  }

  let text = "Database Schema:\n\n";

  for (const [table, cols] of Object.entries(tables)) {
    text += `Table: ${table}\n`;
    text += `Columns:\n`;
    for (const col of cols) {
      const nullable = col.is_nullable === "YES" ? " (nullable)" : "";
      const def = col.column_default ? ` default=${col.column_default}` : "";
      text += `  - ${col.column_name}: ${col.data_type}${nullable}${def}\n`;
    }

    const fks = schema.foreignKeys.filter((fk) => fk.source_table === table);
    if (fks.length > 0) {
      text += `Foreign Keys:\n`;
      for (const fk of fks) {
        text += `  - ${fk.source_column} → ${fk.target_table}.${fk.target_column}\n`;
      }
    }
    text += "\n";
  }

  return text;
}
