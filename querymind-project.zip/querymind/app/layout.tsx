import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "QueryMind — Natural Language SQL Query Tool",
  description:
    "Ask questions about your data in plain English. Powered by Claude AI.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
