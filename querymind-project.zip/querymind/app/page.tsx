"use client";

import { useState, useCallback } from "react";
import QueryInput from "@/components/QueryInput";
import SQLPreview from "@/components/SQLPreview";
import ResultsTable from "@/components/ResultsTable";
import ChartView from "@/components/ChartView";
import SchemaExplorer from "@/components/SchemaExplorer";
import QueryHistory, { HistoryEntry } from "@/components/QueryHistory";

// ─── Example queries shown to new users ──────────────────────────────────────
const EXAMPLES = [
  "Show me the top 5 most expensive products",
  "What is the total revenue by product category?",
  "Which customers have spent more than $200?",
  "How many orders are in each status?",
  "List all electronics products sorted by rating",
  "What is the average order value per customer?",
];

export default function Home() {
  const [query, setQuery] = useState("");
  const [generatedSQL, setGeneratedSQL] = useState("");
  const [results, setResults] = useState<Record<string, unknown>[] | null>(null);
  const [columns, setColumns] = useState<{ name: string }[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [executionTime, setExecutionTime] = useState<number | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [showSchema, setShowSchema] = useState(false);
  const [activeTab, setActiveTab] = useState<"table" | "chart">("table");

  // ─── Main query handler ──────────────────────────────────────────────────
  const handleQuery = useCallback(
    async (question?: string) => {
      const q = question || query;
      if (!q.trim()) return;

      setLoading(true);
      setError("");
      setResults(null);
      setGeneratedSQL("");
      setExecutionTime(null);

      try {
        // Step 1: Generate SQL via Claude
        const genResponse = await fetch("/api/generate-sql", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            question: q,
            history: history.slice(0, 3).map((h) => ({
              question: h.question,
              sql: h.sql,
            })),
          }),
        });

        const genData = await genResponse.json();
        if (!genResponse.ok) throw new Error(genData.error);

        setGeneratedSQL(genData.sql);

        // Step 2: Execute the SQL
        const execResponse = await fetch("/api/execute-sql", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sql: genData.sql }),
        });

        const execData = await execResponse.json();
        if (!execResponse.ok) throw new Error(execData.error);

        setResults(execData.rows);
        setColumns(execData.columns);
        setExecutionTime(execData.executionTime);

        // Auto-select chart tab if data is chartable
        const hasNumeric = execData.columns?.some((c: { name: string }) =>
          execData.rows?.[0] && typeof execData.rows[0][c.name] === "number"
        );
        setActiveTab(hasNumeric && execData.rows.length > 1 ? "chart" : "table");

        // Add to history
        setHistory((prev) => [
          {
            question: q,
            sql: genData.sql,
            resultCount: execData.rowCount ?? execData.rows.length,
            timestamp: new Date(),
          },
          ...prev.slice(0, 19),
        ]);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Something went wrong.");
      } finally {
        setLoading(false);
      }
    },
    [query, history]
  );

  const handleExampleClick = (example: string) => {
    setQuery(example);
    handleQuery(example);
  };

  const handleHistoryClick = (entry: HistoryEntry) => {
    setQuery(entry.question);
    handleQuery(entry.question);
  };

  return (
    <div className="min-h-screen">
      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <header className="border-b border-[var(--border-subtle)] bg-[rgba(15,23,42,0.8)] backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-bold text-white"
              style={{
                background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                boxShadow: "0 0 20px rgba(99,102,241,0.3)",
              }}
            >
              ⚡
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-100">
                QueryMind
              </h1>
              <p className="text-xs text-slate-500">
                Natural Language → SQL → Results
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowSchema(!showSchema)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all border ${
              showSchema
                ? "bg-[rgba(99,102,241,0.15)] border-[var(--border-accent)] text-[var(--accent-light)]"
                : "bg-[rgba(255,255,255,0.04)] border-[var(--border-accent)] text-[var(--text-secondary)]"
            } hover:border-[var(--accent-light)]`}
          >
            {showSchema ? "✕ Hide" : "◫ Schema"}
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6 space-y-6">
        {/* ── Schema Explorer ────────────────────────────────────────────── */}
        {showSchema && (
          <div className="animate-fade-in">
            <SchemaExplorer />
          </div>
        )}

        {/* ── Query Input ────────────────────────────────────────────────── */}
        <QueryInput
          query={query}
          setQuery={setQuery}
          onSubmit={() => handleQuery()}
          loading={loading}
        />

        {/* ── Example Queries ────────────────────────────────────────────── */}
        {!results && !error && !loading && (
          <div className="animate-fade-in-up">
            <p className="text-xs text-slate-500 mb-3 font-medium">
              Try these examples:
            </p>
            <div className="flex flex-wrap gap-2">
              {EXAMPLES.map((ex) => (
                <button
                  key={ex}
                  onClick={() => handleExampleClick(ex)}
                  className="bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.08)] text-[var(--text-secondary)] px-3.5 py-2 rounded-lg text-sm transition-all hover:border-[rgba(99,102,241,0.3)] hover:text-[var(--accent-light)]"
                >
                  {ex}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* ── Loading State ──────────────────────────────────────────────── */}
        {loading && (
          <div className="text-center py-16 animate-pulse-glow">
            <div className="text-3xl mb-3">⚡</div>
            <p className="text-[var(--accent-light)] font-medium">
              Translating your question to SQL...
            </p>
            <p className="text-slate-600 text-sm mt-1">Powered by Claude AI</p>
          </div>
        )}

        {/* ── Error State ────────────────────────────────────────────────── */}
        {error && (
          <div className="bg-[rgba(239,68,68,0.08)] border border-[rgba(239,68,68,0.2)] rounded-xl p-5 animate-fade-in">
            <p className="text-[var(--error)] font-semibold text-sm mb-1">
              ⚠ Query Error
            </p>
            <p className="text-red-300 text-sm">{error}</p>
          </div>
        )}

        {/* ── Generated SQL ──────────────────────────────────────────────── */}
        {generatedSQL && (
          <div className="animate-fade-in-up">
            <SQLPreview sql={generatedSQL} executionTime={executionTime} />
          </div>
        )}

        {/* ── Results ────────────────────────────────────────────────────── */}
        {results && results.length > 0 && (
          <div className="bg-[var(--bg-card)] border border-[var(--border-subtle)] rounded-xl overflow-hidden animate-fade-in-up">
            {/* Tabs */}
            <div className="flex border-b border-[rgba(255,255,255,0.06)] px-4">
              <button
                onClick={() => setActiveTab("table")}
                className={`px-4 py-3 text-sm font-medium transition-all border-b-2 ${
                  activeTab === "table"
                    ? "border-[var(--accent-light)] text-[var(--accent-light)]"
                    : "border-transparent text-[var(--text-muted)]"
                }`}
              >
                Table ({results.length} rows)
              </button>
              <button
                onClick={() => setActiveTab("chart")}
                className={`px-4 py-3 text-sm font-medium transition-all border-b-2 ${
                  activeTab === "chart"
                    ? "border-[var(--accent-light)] text-[var(--accent-light)]"
                    : "border-transparent text-[var(--text-muted)]"
                }`}
              >
                Chart
              </button>
            </div>

            <div className="p-4">
              {activeTab === "table" ? (
                <ResultsTable rows={results} />
              ) : (
                <ChartView data={results} />
              )}
            </div>
          </div>
        )}

        {/* ── Empty results ──────────────────────────────────────────────── */}
        {results && results.length === 0 && (
          <div className="text-center py-12 animate-fade-in">
            <p className="text-slate-400">No results found for this query.</p>
          </div>
        )}

        {/* ── Query History ──────────────────────────────────────────────── */}
        {history.length > 0 && (
          <QueryHistory history={history} onSelect={handleHistoryClick} />
        )}
      </main>
    </div>
  );
}
