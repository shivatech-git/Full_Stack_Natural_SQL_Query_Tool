// ─── POST /api/generate-sql ──────────────────────────────────────────────────
// Accepts a natural language question, sends it to Claude with the database
// schema, and returns the generated SQL. The API key stays server-side.

import { NextRequest, NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { getSchema, formatSchemaForPrompt } from "@/lib/database";
import { buildMessages } from "@/lib/promptBuilder";

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Simple in-memory rate limiter (use Redis in production)
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
const RATE_LIMIT = 20; // requests per minute
const RATE_WINDOW = 60_000; // 1 minute

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const entry = rateLimitMap.get(ip);

  if (!entry || now > entry.resetAt) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + RATE_WINDOW });
    return true;
  }

  if (entry.count >= RATE_LIMIT) return false;
  entry.count++;
  return true;
}

export async function POST(request: NextRequest) {
  try {
    // Rate limiting
    const ip = request.headers.get("x-forwarded-for") ?? "unknown";
    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        { error: "Too many requests. Please wait a moment and try again." },
        { status: 429 }
      );
    }

    // Parse request body
    const body = await request.json();
    const { question, history } = body;

    if (!question || typeof question !== "string") {
      return NextResponse.json(
        { error: "Please provide a question." },
        { status: 400 }
      );
    }

    if (question.length > 500) {
      return NextResponse.json(
        { error: "Question is too long. Please keep it under 500 characters." },
        { status: 400 }
      );
    }

    // Get database schema
    const schema = await getSchema();
    const schemaText = formatSchemaForPrompt(schema);

    // Build the prompt
    const { system, messages } = buildMessages({
      schemaText,
      userQuestion: question,
      conversationHistory: history,
    });

    // Call Claude
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system,
      messages,
    });

    // Extract the SQL from the response
    const sql = response.content
      .filter((block) => block.type === "text")
      .map((block) => {
        if (block.type === "text") return block.text;
        return "";
      })
      .join("")
      .trim()
      .replace(/```sql|```/g, "")
      .trim();

    if (!sql) {
      return NextResponse.json(
        { error: "Failed to generate SQL. Please try rephrasing your question." },
        { status: 500 }
      );
    }

    return NextResponse.json({
      sql,
      model: response.model,
      usage: response.usage,
    });
  } catch (error) {
    console.error("[generate-sql] Error:", error);

    if (error instanceof Anthropic.APIError) {
      return NextResponse.json(
        { error: `AI service error: ${error.message}` },
        { status: 502 }
      );
    }

    return NextResponse.json(
      { error: "Internal server error. Please try again." },
      { status: 500 }
    );
  }
}
