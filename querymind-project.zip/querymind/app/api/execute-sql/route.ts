// ─── POST /api/execute-sql ───────────────────────────────────────────────────
// Validates and executes AI-generated SQL against the database.
// Returns rows + column metadata for the frontend to render.

import { NextRequest, NextResponse } from "next/server";
import { pool } from "@/lib/database";
import {
  validateSQL,
  addRowLimit,
  QUERY_TIMEOUT_MS,
  MAX_ROWS,
} from "@/lib/sqlValidator";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sql } = body;

    // ── Step 1: Validate the SQL ──────────────────────────────────────────
    const validation = validateSQL(sql);
    if (!validation.valid) {
      return NextResponse.json(
        { error: validation.error },
        { status: 400 }
      );
    }

    const safeSql = addRowLimit(validation.sanitizedSQL!);

    // ── Step 2: Execute with timeout ──────────────────────────────────────
    const client = await pool.connect();

    try {
      // Set a statement timeout to prevent runaway queries
      await client.query(`SET statement_timeout = ${QUERY_TIMEOUT_MS}`);

      const startTime = performance.now();
      const result = await client.query(safeSql);
      const executionTime = Math.round(performance.now() - startTime);

      // Extract column info
      const columns = result.fields.map((field) => ({
        name: field.name,
        dataTypeID: field.dataTypeID,
      }));

      return NextResponse.json({
        rows: result.rows.slice(0, MAX_ROWS),
        columns,
        rowCount: result.rowCount,
        executionTime,
        truncated: (result.rowCount ?? 0) > MAX_ROWS,
      });
    } finally {
      // Reset timeout and release
      await client.query("RESET statement_timeout").catch(() => {});
      client.release();
    }
  } catch (error: unknown) {
    console.error("[execute-sql] Error:", error);

    // Handle PostgreSQL-specific errors with helpful messages
    const pgError = error as { code?: string; message?: string; position?: string };

    if (pgError.code === "57014") {
      return NextResponse.json(
        { error: "Query timed out. Try a simpler query or add filters to reduce results." },
        { status: 408 }
      );
    }

    if (pgError.code === "42P01") {
      return NextResponse.json(
        { error: `Table not found. ${pgError.message}` },
        { status: 400 }
      );
    }

    if (pgError.code === "42703") {
      return NextResponse.json(
        { error: `Column not found. ${pgError.message}` },
        { status: 400 }
      );
    }

    if (pgError.code?.startsWith("42")) {
      return NextResponse.json(
        { error: `SQL syntax error: ${pgError.message}` },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: "Failed to execute query. Please try again." },
      { status: 500 }
    );
  }
}
