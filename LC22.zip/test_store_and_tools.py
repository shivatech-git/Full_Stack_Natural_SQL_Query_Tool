"""
Tests that run WITHOUT any API key or network.

They cover the deterministic parts: the local store and the tools that don't hit
the network (calculator + the todo/memory tools). Run with:  pytest
"""

import importlib

import pytest


@pytest.fixture(autouse=True)
def temp_data_dir(tmp_path, monkeypatch):
    """Point the store at a throwaway directory for each test."""
    monkeypatch.setenv("ASSISTANT_DATA_DIR", str(tmp_path))
    # Reload store so any cached path logic picks up the new env var.
    import assistant.store as store
    importlib.reload(store)
    return store


def test_add_and_get_facts(temp_data_dir):
    store = temp_data_dir
    store.add_fact("prefers tea over coffee")
    assert "prefers tea over coffee" in store.get_facts()


def test_todo_lifecycle(temp_data_dir):
    store = temp_data_dir
    todo = store.add_todo("buy milk")
    assert todo["id"] == 1 and todo["done"] is False

    open_todos = store.list_todos()
    assert len(open_todos) == 1

    done = store.complete_todo("milk")            # match by text
    assert done is not None and done["done"] is True
    assert store.list_todos() == []               # nothing outstanding now
    assert store.complete_todo("nonexistent") is None


def test_calculator_tool():
    from assistant.tools import calculator

    assert calculator.invoke({"expression": "2 + 2"}).endswith("= 4")
    # Anything non-arithmetic is rejected, never executed.
    assert "allowed" in calculator.invoke({"expression": "__import__('os')"}).lower()


def test_todo_tools_roundtrip(temp_data_dir):
    from assistant.tools import add_todo, complete_todo, list_todos

    add_todo.invoke({"task": "write tests"})
    assert "write tests" in list_todos.invoke({})
    assert "done" in complete_todo.invoke({"identifier": "1"}).lower()
