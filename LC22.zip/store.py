"""
A tiny local persistence layer for the agent's long-term memory.

This is deliberately simple (a single JSON file) but it's what turns the agent
from stateless into something that *remembers* facts and tracks todos across
runs. The data directory is configurable via ASSISTANT_DATA_DIR, which also makes
it trivial to point tests at a temporary folder.
"""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

_LOCK = threading.Lock()  # guards read-modify-write against interleaving


def _data_dir() -> Path:
    path = Path(os.getenv("ASSISTANT_DATA_DIR", "data"))
    path.mkdir(parents=True, exist_ok=True)
    return path


def _store_path() -> Path:
    return _data_dir() / "store.json"


def _load() -> dict:
    path = _store_path()
    if not path.exists():
        return {"facts": [], "todos": [], "_next_id": 1}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        # Corrupt file shouldn't take the agent down; start fresh.
        return {"facts": [], "todos": [], "_next_id": 1}


def _save(data: dict) -> None:
    _store_path().write_text(json.dumps(data, indent=2), encoding="utf-8")


# --- Facts -----------------------------------------------------------------
def add_fact(fact: str) -> str:
    with _LOCK:
        data = _load()
        entry = {"fact": fact.strip(), "at": datetime.now(timezone.utc).isoformat()}
        data["facts"].append(entry)
        _save(data)
    return entry["fact"]


def get_facts() -> list[str]:
    return [f["fact"] for f in _load().get("facts", [])]


# --- Todos -----------------------------------------------------------------
def add_todo(task: str) -> dict:
    with _LOCK:
        data = _load()
        todo = {"id": data.get("_next_id", 1), "task": task.strip(), "done": False}
        data["todos"].append(todo)
        data["_next_id"] = todo["id"] + 1
        _save(data)
    return todo


def list_todos(include_done: bool = False) -> list[dict]:
    todos = _load().get("todos", [])
    return todos if include_done else [t for t in todos if not t["done"]]


def complete_todo(identifier: str) -> dict | None:
    """Complete a todo by numeric id or by a case-insensitive text match."""
    with _LOCK:
        data = _load()
        target = None
        for todo in data["todos"]:
            if str(todo["id"]) == identifier.strip() or identifier.lower() in todo["task"].lower():
                target = todo
                break
        if target is None:
            return None
        target["done"] = True
        _save(data)
    return target
