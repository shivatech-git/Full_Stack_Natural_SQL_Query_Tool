"""
Custom middleware — the defining feature of LangChain 1.0's create_agent.

Middleware lets you intercept the agent loop without rewriting it. We add two:

  1. RetryMiddleware (class-style, wraps the model call): if the model call fails
     — most importantly a free-tier rate limit (HTTP 429) — it retries with
     exponential backoff instead of letting the whole run die. This is the single
     most useful piece of resilience when running on free API tiers.

  2. log_turn (decorator-style @before_model hook): logs how many messages are in
     context at the start of each model call. A minimal example of observability.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Callable

from langchain.agents.middleware import AgentMiddleware, before_model

logger = logging.getLogger("assistant.middleware")


class RetryMiddleware(AgentMiddleware):
    """Retry the model call with exponential backoff on transient failures."""

    def __init__(self, max_retries: int = 3, base_delay: float = 1.0):
        super().__init__()
        self.max_retries = max_retries
        self.base_delay = base_delay

    def wrap_model_call(self, request: Any, handler: Callable[[Any], Any]) -> Any:
        last_error: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                return handler(request)
            except Exception as exc:  # noqa: BLE001 - we deliberately retry broadly
                last_error = exc
                if attempt == self.max_retries - 1:
                    raise
                delay = self.base_delay * (2 ** attempt)
                logger.warning(
                    "Model call failed (attempt %d/%d): %s — retrying in %.1fs",
                    attempt + 1, self.max_retries, exc, delay,
                )
                time.sleep(delay)
        # Unreachable, but keeps type checkers happy.
        raise last_error  # type: ignore[misc]


@before_model
def log_turn(state: dict, runtime: Any) -> dict | None:
    """Log context size before each model call. Returns None (no state change)."""
    logger.info("Model turn starting with %d messages in context", len(state["messages"]))
    return None
