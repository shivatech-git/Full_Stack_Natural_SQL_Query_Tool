"""
The agent.

  * get_model()        — build the chat model (Groq by default, Gemini optional).
  * build_agent()      — a create_agent graph with custom middleware; optionally
                         persistent via a checkpointer.
  * build_chat_agent() — an agent backed by a SQLite checkpointer so interactive
                         chat remembers across sessions (keyed by thread_id).
  * generate_brief()   — the two-stage gather -> format morning-brief pipeline.
"""

from __future__ import annotations

import logging
import sqlite3

from langchain.agents import create_agent
from langchain_groq import ChatGroq

from assistant.config import get_settings
from assistant.middleware import RetryMiddleware, log_turn
from assistant.schemas import MorningBrief
from assistant.tools import ALL_TOOLS

logger = logging.getLogger("assistant.agent")

_SYSTEM_PROMPT = (
    "You are a proactive daily personal assistant. You have tools for date/time, "
    "weather, news, web search, currency, arithmetic, and a long-term memory of "
    "facts and todos. Decide which tools to call and call them yourself rather than "
    "asking the user to. When a request depends on the user's preferences or past "
    "context, call recall_facts first. When the user reveals a lasting preference, "
    "save it with remember_fact. Prefer real tool data over guessing, and never "
    "fabricate headlines or numbers. Be concise, warm, and practical."
)


def get_model(temperature: float | None = None):
    """Build the chat model based on the configured provider."""
    settings = get_settings()
    temp = settings.temperature if temperature is None else temperature

    if settings.provider == "google":
        # Optional path: pip install langchain-google-genai
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(
            model=settings.model, temperature=temp, google_api_key=settings.google_api_key
        )

    return ChatGroq(model=settings.model, temperature=temp, api_key=settings.groq_api_key)


def _middleware():
    """The middleware stack applied to every model call."""
    return [RetryMiddleware(max_retries=3, base_delay=1.0), log_turn]


def build_agent(checkpointer=None):
    """A tool-calling agent. Pass a checkpointer to make it stateful."""
    return create_agent(
        model=get_model(),
        tools=ALL_TOOLS,
        system_prompt=_SYSTEM_PROMPT,
        middleware=_middleware(),
        checkpointer=checkpointer,
    )


def build_chat_agent(db_path: str = "data/checkpoints.sqlite"):
    """Build a chat agent whose memory persists in a SQLite file."""
    from langgraph.checkpoint.sqlite import SqliteSaver

    conn = sqlite3.connect(db_path, check_same_thread=False)
    checkpointer = SqliteSaver(conn)
    checkpointer.setup()  # idempotently create the checkpoint tables
    logger.info("Chat memory persisting to %s", db_path)
    return build_agent(checkpointer=checkpointer)


def _last_text(result: dict) -> str:
    """Pull the final assistant text out of an agent result."""
    messages = result.get("messages", [])
    for msg in reversed(messages):
        if getattr(msg, "type", "") == "ai" and getattr(msg, "content", ""):
            content = msg.content
            return content if isinstance(content, str) else str(content)
    return getattr(messages[-1], "content", "") if messages else ""


def generate_brief(city: str | None = None) -> MorningBrief:
    """Run the gather -> format pipeline and return a structured MorningBrief."""
    settings = get_settings()
    city = city or settings.default_city

    # ---- Stage 1: GATHER (agent freely calls tools; stateless is fine) ----
    agent = build_agent()
    request = (
        f"Prepare my morning brief. My name is {settings.user_name}. "
        f"First recall any saved facts about me. Then check the current date and "
        f"time, get today's weather for {city}, and get the top news headlines. "
        f"Also list my outstanding todos. Summarize everything you found clearly, "
        f"including the concrete weather numbers, the actual headlines, and my todos."
    )
    gathered = _last_text(agent.invoke({"messages": [{"role": "user", "content": request}]}))

    # ---- Stage 2: FORMAT (structured output, no tools) ----
    formatter = get_model(temperature=0.4).with_structured_output(MorningBrief)
    brief: MorningBrief = formatter.invoke(
        "Turn the notes below into a polished morning brief for "
        f"{settings.user_name}. Rewrite headlines in your own words; do not copy "
        "them verbatim. If there are todos, weave the most important one into the "
        "focus suggestion. Keep it warm and practical.\n\n"
        f"NOTES:\n{gathered}"
    )
    return brief
