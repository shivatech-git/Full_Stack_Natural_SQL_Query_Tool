"""
Command-line entry point.

Usage:
    python main.py brief                      # morning brief (default city)
    python main.py brief --city Tokyo         # brief for another city
    python main.py chat                        # interactive agent, persistent memory
    python main.py chat --thread work          # a separate named memory thread
"""

from __future__ import annotations

import argparse
import sys

from rich.console import Console

from assistant.config import configure_logging

console = Console()


def _print_stream_chunk(chunk: dict) -> None:
    """Render one streamed update from the agent: tool calls, results, answers."""
    for _node, update in chunk.items():
        for msg in update.get("messages", []):
            tool_calls = getattr(msg, "tool_calls", None)
            if tool_calls:
                for call in tool_calls:
                    console.print(f"[dim]→ {call['name']}({call.get('args', {})})[/dim]")
            elif getattr(msg, "type", "") == "tool":
                preview = str(getattr(msg, "content", ""))[:200]
                console.print(f"[dim]  ↳ {preview}[/dim]")
            elif getattr(msg, "content", ""):
                console.print(f"\n[bold cyan]Assistant:[/bold cyan] {msg.content}\n")


def cmd_brief(args: argparse.Namespace) -> None:
    from assistant.agent import generate_brief
    from assistant.render import render_brief

    with console.status("[cyan]Gathering your day...[/cyan]", spinner="dots"):
        brief = generate_brief(city=args.city)
    render_brief(brief)


def cmd_chat(args: argparse.Namespace) -> None:
    from assistant.agent import build_chat_agent

    agent = build_chat_agent()
    config = {"configurable": {"thread_id": args.thread}}
    console.print(
        f"[bold green]Daily assistant ready[/bold green] (memory thread: '{args.thread}'). "
        "Ask anything. Type 'exit' to quit.\n"
    )

    while True:
        try:
            user = console.input("[bold]You:[/bold] ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if user.lower() in {"exit", "quit", "q"}:
            break
        if not user:
            continue

        # The checkpointer restores prior turns for this thread automatically,
        # so we only send the new message — no manual history juggling.
        for chunk in agent.stream(
            {"messages": [{"role": "user", "content": user}]},
            config=config,
            stream_mode="updates",
        ):
            _print_stream_chunk(chunk)

    console.print("\n[dim]Goodbye.[/dim]")


def main() -> None:
    configure_logging()
    parser = argparse.ArgumentParser(description="Daily personal assistant agent")
    sub = parser.add_subparsers(dest="command", required=True)

    p_brief = sub.add_parser("brief", help="Generate a structured morning brief")
    p_brief.add_argument("--city", default=None, help="Override the default city")
    p_brief.set_defaults(func=cmd_brief)

    p_chat = sub.add_parser("chat", help="Chat interactively with persistent memory")
    p_chat.add_argument("--thread", default="default", help="Named memory thread")
    p_chat.set_defaults(func=cmd_chat)

    args = parser.parse_args()
    try:
        args.func(args)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    main()
