# Daily Personal Assistant Agent

A tool-calling AI agent that prepares a structured morning brief and chats
interactively with **persistent memory**, deciding for itself which tools to
call. Built on **LangChain 1.0 `create_agent`** (LangGraph under the hood) with
custom middleware and **free, mostly keyless APIs**.

## What makes this advanced
- **Real agent loop** via `create_agent`: the model reasons, picks tools, reads
  results, and iterates until done.
- **Custom middleware** (`assistant/middleware.py`) — the defining feature of
  `create_agent`:
  - `RetryMiddleware` wraps every model call and retries with exponential backoff
    on transient errors, including free-tier rate limits (HTTP 429).
  - `log_turn` (a `@before_model` hook) logs context size each turn.
- **Persistent memory two ways:**
  - *Conversation memory* — a SQLite **checkpointer** so `chat` remembers across
    runs, keyed by `--thread`.
  - *Long-term memory* — a JSON store (`assistant/store.py`) exposed as tools so
    the agent can save facts and manage a to-do list that survive restarts.
- **Two-stage brief pipeline:** the agent *gathers* with tools, then a structured
  pass *formats* the result into a typed `MorningBrief`.
- **Resilient + observable:** every tool returns friendly text instead of raising,
  network calls retry with backoff, and everything logs.
- **Pluggable provider:** Groq by default; switch to Gemini with one env var.
- **Tested:** a `pytest` suite covers the store and offline tools (no key needed).

## Architecture
```
daily_assistant/
├── assistant/
│   ├── config.py       # immutable Settings from .env + logging setup
│   ├── schemas.py      # MorningBrief / NewsHighlight (typed output)
│   ├── store.py        # JSON-backed long-term memory (facts + todos)
│   ├── tools.py        # 11 tools; keyless-first, retrying HTTP, graceful
│   ├── middleware.py   # RetryMiddleware + log_turn
│   ├── agent.py        # get_model / build_agent / build_chat_agent / brief
│   └── render.py       # rich terminal panels
├── tests/
│   └── test_store_and_tools.py
├── main.py             # CLI: `brief` and persistent `chat`
├── requirements.txt
├── .env.example
└── .gitignore
```

## Setup
```bash
pip install -r requirements.txt
cp .env.example .env          # paste your free Groq key into .env
```
Free Groq key (no card): https://console.groq.com/keys

## Run
```bash
python main.py brief                 # morning brief
python main.py brief --city Tokyo
python main.py chat                  # persistent conversation (thread 'default')
python main.py chat --thread work    # a separate memory thread
pytest                               # run the offline test suite
```
Try in `chat`: *"Remember I'm vegetarian and add 'book dentist' to my todos."*
Then quit, restart, and ask *"what do you know about me and what's on my list?"* —
it recalls both across sessions.

## The tools
| Tool | Source | Key |
|---|---|---|
| `get_current_datetime` | system clock + timezone | no |
| `get_current_weather` | Open-Meteo | no |
| `get_news_headlines` | NewsAPI → RSS fallback | optional |
| `web_search` | DuckDuckGo (ddgs) | no |
| `get_exchange_rate` | open.er-api.com | no |
| `calculator` | safe arithmetic | no |
| `remember_fact` / `recall_facts` | local store | no |
| `add_todo` / `list_todos` / `complete_todo` | local store | no |

## Switching to Gemini
```
# in .env
LLM_PROVIDER=google
GOOGLE_API_KEY=your_key      # https://aistudio.google.com/apikey
```
Then `pip install langchain-google-genai`. Nothing else changes.

## Further advanced steps
- **Human-in-the-loop:** add `HumanInTheLoopMiddleware(interrupt_on={...})` to
  require approval before any future action tool (e.g. `send_email`). Requires a
  checkpointer (you already have one) and handling interrupts in the invoke loop.
- **Summarization middleware** to compress very long threads automatically.
- **Calendar/email tools** via an MCP connector.
- **Schedule** `python main.py brief` with cron to email yourself each morning.

## Notes on free tiers
Free LLM tiers change often and many train on your prompts — keep sensitive data
out. `RetryMiddleware` already smooths over the occasional 429.
