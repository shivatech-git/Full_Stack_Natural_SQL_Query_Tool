"""
Tools the agent can call.

Design principles:
  1. Precise docstrings — the model reads them to decide when/how to call a tool.
  2. Tools NEVER raise. On failure they return a short string; the agent treats
     that as data and keeps going.
  3. Keyless free APIs preferred; transparently upgrade when an optional key exists.
  4. Network calls go through a retry/backoff helper for transient failures.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import requests
from langchain_core.tools import tool

from assistant import store
from assistant.config import get_settings

logger = logging.getLogger("assistant.tools")

_TIMEOUT = 12  # seconds


def _get_json(url: str, params: dict | None = None, attempts: int = 3) -> dict:
    """GET JSON with exponential backoff on transient network errors."""
    last: Exception | None = None
    for i in range(attempts):
        try:
            resp = requests.get(url, params=params, timeout=_TIMEOUT)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            last = exc
            if i < attempts - 1:
                delay = 0.6 * (2 ** i)
                logger.debug("GET %s failed (%s); retrying in %.1fs", url, exc, delay)
                time.sleep(delay)
    raise last  # type: ignore[misc]


_WMO = {
    0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast",
    45: "fog", 48: "depositing rime fog", 51: "light drizzle", 53: "drizzle",
    55: "dense drizzle", 61: "light rain", 63: "rain", 65: "heavy rain",
    71: "light snow", 73: "snow", 75: "heavy snow", 80: "rain showers",
    81: "rain showers", 82: "violent rain showers", 95: "thunderstorm",
    96: "thunderstorm with hail", 99: "severe thunderstorm with hail",
}


# ============================ Information tools ============================
@tool
def get_current_weather(city: str = "") -> str:
    """Get today's weather (current conditions and the day's high/low) for a city.
    Pass a city name like 'Berlin'. Leave empty to use the user's default city."""
    settings = get_settings()
    city = city.strip() or settings.default_city
    try:
        geo = _get_json(
            "https://geocoding-api.open-meteo.com/v1/search",
            {"name": city, "count": 1},
        )
        results = geo.get("results")
        if not results:
            return f"Couldn't find a location called '{city}'."
        place = results[0]
        label = f"{place.get('name', city)}, {place.get('country_code', '')}".strip(", ")
        unit = "fahrenheit" if settings.units.lower().startswith("f") else "celsius"
        wx = _get_json(
            "https://api.open-meteo.com/v1/forecast",
            {
                "latitude": place["latitude"], "longitude": place["longitude"],
                "current": "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
                "daily": "temperature_2m_max,temperature_2m_min,weather_code",
                "temperature_unit": unit, "timezone": "auto",
            },
        )
        cur, daily, sym = wx["current"], wx["daily"], settings.temp_symbol
        desc = _WMO.get(cur["weather_code"], "unknown conditions")
        return (
            f"Weather in {label}: {desc}, currently {round(cur['temperature_2m'])}{sym} "
            f"(feels like {round(cur['apparent_temperature'])}{sym}), "
            f"humidity {cur['relative_humidity_2m']}%, wind {round(cur['wind_speed_10m'])} km/h. "
            f"Today's range: {round(daily['temperature_2m_min'][0])}{sym} to "
            f"{round(daily['temperature_2m_max'][0])}{sym}."
        )
    except Exception as exc:  # noqa: BLE001
        return f"Weather lookup failed: {exc}"


@tool
def get_news_headlines(topic: str = "") -> str:
    """Get current news headlines. Optionally pass a topic like 'technology'.
    Uses NewsAPI if a key is configured, otherwise a keyless RSS feed."""
    settings = get_settings()
    topic = topic.strip()

    if settings.news_api_key:
        try:
            params = {"language": "en", "pageSize": 6, "apiKey": settings.news_api_key}
            params["q" if topic else "country"] = topic or "us"
            data = _get_json("https://newsapi.org/v2/top-headlines", params)
            articles = data.get("articles", [])
            if articles:
                lines = [f"- {a['title']} ({a['source']['name']})" for a in articles[:6]]
                return "Top headlines:\n" + "\n".join(lines)
        except Exception:  # noqa: BLE001 - fall through to RSS
            pass

    try:
        import feedparser

        feed = feedparser.parse(settings.news_rss_url)
        entries = feed.entries[:6]
        if not entries:
            return "No headlines available right now."
        note = f" (filter by '{topic}' if relevant)" if topic else ""
        return f"Top headlines{note}:\n" + "\n".join(f"- {e.title}" for e in entries)
    except Exception as exc:  # noqa: BLE001
        return f"News lookup failed: {exc}"


@tool
def web_search(query: str) -> str:
    """Search the web for up-to-date information on any question or topic.
    Use this for facts not covered by the other tools."""
    query = query.strip()
    if not query:
        return "No search query provided."
    try:
        try:
            from ddgs import DDGS
        except ImportError:
            from duckduckgo_search import DDGS

        with DDGS() as ddgs:
            hits = list(ddgs.text(query, max_results=5))
        if not hits:
            return f"No web results for '{query}'."
        return "\n".join(f"- {h.get('title', '')}: {h.get('body', '')[:180]}" for h in hits)
    except Exception as exc:  # noqa: BLE001
        return f"Web search failed: {exc}"


@tool
def get_current_datetime() -> str:
    """Return the current date and time in the user's timezone. Call this first
    when preparing anything time-sensitive like a morning brief."""
    settings = get_settings()
    try:
        now = datetime.now(ZoneInfo(settings.timezone))
    except Exception:  # noqa: BLE001
        now = datetime.now()
    return now.strftime("%A, %d %B %Y, %I:%M %p")


@tool
def get_exchange_rate(base: str = "USD", target: str = "INR") -> str:
    """Get the current exchange rate between two currency codes, e.g. base='USD',
    target='EUR'. Useful for travel or finance questions."""
    base, target = base.upper().strip(), target.upper().strip()
    try:
        data = _get_json(f"https://open.er-api.com/v6/latest/{base}")
        rate = data.get("rates", {}).get(target)
        if rate is None:
            return f"Couldn't find a rate for {base}->{target}."
        return f"1 {base} = {rate} {target} (updated {data.get('time_last_update_utc', 'recently')})."
    except Exception as exc:  # noqa: BLE001
        return f"Exchange-rate lookup failed: {exc}"


@tool
def calculator(expression: str) -> str:
    """Evaluate a basic arithmetic expression, e.g. '(1200 * 0.08) / 12'.
    Only numbers and + - * / ( ) . are allowed."""
    allowed = set("0123456789+-*/(). ")
    if not expression or set(expression) - allowed:
        return "Only basic arithmetic (numbers and + - * / ( ) .) is allowed."
    try:
        return f"{expression} = {eval(expression, {'__builtins__': {}}, {})}"
    except Exception as exc:  # noqa: BLE001
        return f"Couldn't evaluate that: {exc}"


# ========================= Long-term memory tools =========================
@tool
def remember_fact(fact: str) -> str:
    """Save a durable fact about the user for future sessions, e.g. their
    preferences, goals, or important dates. Use when the user says to remember
    something or reveals a lasting preference."""
    saved = store.add_fact(fact)
    return f"Got it, I'll remember: {saved}"


@tool
def recall_facts() -> str:
    """Retrieve everything previously saved about the user. Call this when you
    need context about the user's preferences, goals, or history."""
    facts = store.get_facts()
    return "Known facts:\n" + "\n".join(f"- {f}" for f in facts) if facts else "I don't have any saved facts yet."


@tool
def add_todo(task: str) -> str:
    """Add a task to the user's to-do list."""
    todo = store.add_todo(task)
    return f"Added todo #{todo['id']}: {todo['task']}"


@tool
def list_todos() -> str:
    """List the user's outstanding (not-yet-done) to-do items."""
    todos = store.list_todos()
    if not todos:
        return "Your to-do list is empty. Nice."
    return "Outstanding todos:\n" + "\n".join(f"- #{t['id']} {t['task']}" for t in todos)


@tool
def complete_todo(identifier: str) -> str:
    """Mark a to-do as done. Pass its number (e.g. '3') or part of its text."""
    done = store.complete_todo(identifier)
    return f"Marked done: {done['task']}" if done else f"No matching todo for '{identifier}'."


ALL_TOOLS = [
    get_current_datetime,
    get_current_weather,
    get_news_headlines,
    web_search,
    get_exchange_rate,
    calculator,
    remember_fact,
    recall_facts,
    add_todo,
    list_todos,
    complete_todo,
]
