"""
Central configuration.

Read once from environment variables (loaded from .env) and exposed as an
immutable Settings object. Tools and the agent never touch os.environ directly.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from functools import lru_cache

from dotenv import load_dotenv

load_dotenv()


def configure_logging() -> None:
    """Set up logging once. Level is controlled by LOG_LEVEL (default INFO)."""
    level = os.getenv("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s  %(levelname)-7s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
    )


@dataclass(frozen=True)
class Settings:
    # --- Required ---
    groq_api_key: str

    # --- Model / provider ---
    provider: str = "groq"                    # "groq" or "google"
    model: str = "llama-3.3-70b-versatile"    # free on Groq, reliable tool calling
    temperature: float = 0.3
    google_api_key: str | None = None         # only needed if provider == "google"

    # --- Personalization ---
    user_name: str = "there"
    default_city: str = "Hyderabad"
    timezone: str = "Asia/Kolkata"
    units: str = "celsius"                     # "celsius" or "fahrenheit"

    # --- Optional upgrades (app works fully without these) ---
    news_api_key: str | None = None
    news_rss_url: str = "http://feeds.bbci.co.uk/news/rss.xml"

    @property
    def temp_symbol(self) -> str:
        return "°F" if self.units.lower().startswith("f") else "°C"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Build and cache Settings. Fails early if required keys are missing."""
    def _get(name: str, default: str) -> str:
        return os.getenv(name, "").strip() or default

    provider = _get("LLM_PROVIDER", "groq").lower()

    groq_key = os.getenv("GROQ_API_KEY", "").strip()
    google_key = os.getenv("GOOGLE_API_KEY", "").strip() or None

    # Validate the key for whichever provider is selected.
    if provider == "groq" and not groq_key:
        raise RuntimeError(
            "GROQ_API_KEY is not set. Copy .env.example to .env and add your free "
            "key from https://console.groq.com/keys"
        )
    if provider == "google" and not google_key:
        raise RuntimeError(
            "LLM_PROVIDER=google but GOOGLE_API_KEY is not set. Get a free key at "
            "https://aistudio.google.com/apikey"
        )

    default_model = "gemini-2.5-flash" if provider == "google" else "llama-3.3-70b-versatile"

    return Settings(
        groq_api_key=groq_key,
        provider=provider,
        model=_get("MODEL", default_model),
        temperature=float(_get("TEMPERATURE", "0.3")),
        google_api_key=google_key,
        user_name=_get("USER_NAME", "there"),
        default_city=_get("DEFAULT_CITY", "Hyderabad"),
        timezone=_get("TIMEZONE", "Asia/Kolkata"),
        units=_get("UNITS", "celsius"),
        news_api_key=(os.getenv("NEWS_API_KEY", "").strip() or None),
        news_rss_url=_get("NEWS_RSS_URL", "http://feeds.bbci.co.uk/news/rss.xml"),
    )
