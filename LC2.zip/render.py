"""Pretty terminal rendering for the morning brief."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from assistant.schemas import MorningBrief

console = Console()


def render_brief(brief: MorningBrief) -> None:
    """Print the brief as a set of clean panels."""
    header = Text(f"{brief.greeting}\n{brief.date_line}", justify="center", style="bold cyan")
    console.print(Panel(header, border_style="cyan"))

    console.print(Panel(brief.weather_summary, title="☀  Weather", border_style="yellow"))

    if brief.top_stories:
        body = Text()
        for i, story in enumerate(brief.top_stories, 1):
            body.append(f"{i}. {story.headline}\n", style="bold")
            body.append(f"   {story.why_it_matters}\n\n", style="dim")
        console.print(Panel(body, title="📰  Headlines", border_style="magenta"))

    console.print(Panel(brief.focus_suggestion, title="🎯  Focus Today", border_style="green"))
    console.print(Panel(Text(brief.quote, style="italic"), title="💬  Thought", border_style="blue"))
