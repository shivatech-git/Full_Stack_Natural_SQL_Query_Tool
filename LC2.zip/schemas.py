"""
Typed shapes for the agent's structured output.

The agent gathers raw information with tools, then a second pass fills in this
MorningBrief structure. Because it's typed, the rest of the app (rendering,
saving, sending) can rely on the fields existing.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class NewsHighlight(BaseModel):
    headline: str = Field(description="A concise, rewritten headline (not copied verbatim).")
    why_it_matters: str = Field(description="One short sentence on why the reader should care.")


class MorningBrief(BaseModel):
    """A complete, ready-to-read morning brief."""

    greeting: str = Field(description="A warm one-line greeting addressed to the user.")
    date_line: str = Field(description="Today's date and day of week in plain language.")
    weather_summary: str = Field(
        description="One or two friendly sentences summarizing today's weather and what to wear/bring."
    )
    top_stories: list[NewsHighlight] = Field(
        default_factory=list, description="3-5 of the most relevant news highlights."
    )
    focus_suggestion: str = Field(
        description="A concrete suggestion for how to prioritize the day, grounded in the brief."
    )
    quote: str = Field(description="A short, uplifting quote or thought to start the day.")
