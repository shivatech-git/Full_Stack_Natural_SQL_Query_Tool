# Meeting → Action Items

A tiny LangChain project that turns a meeting transcript (or audio recording)
into a clean summary, a list of decisions, and action items with owners — using
only **free** APIs.

## What you'll learn
- How to call a model through LangChain (`ChatGroq`)
- **Structured output** — forcing the model to return clean data, not messy text
  (the single most useful LangChain skill)
- A first taste of a LangChain "chain" with the `prompt | model` syntax

## Setup (about 5 minutes)

1. **Install Python 3.10+**, then install the dependencies:
   ```bash
   pip install -r requirements.txt
   ```

2. **Get a free Groq key** at https://console.groq.com/keys — no credit card needed.

3. **Add your key.** Copy `.env.example` to a file named `.env` and paste your key:
   ```
   GROQ_API_KEY=gsk_your_key_here
   ```

## Run it

Try the included sample first — no audio needed:
```bash
python meeting_assistant.py
```

Then use your own files:
```bash
python meeting_assistant.py my_meeting.txt      # your transcript
python meeting_assistant.py my_meeting.mp3      # your audio (auto-transcribed)
```

It prints the notes and saves a Markdown file next to your input (e.g.
`sample_transcript_notes.md`).

## How it works (the 3 steps in the code)
1. **Define the output shape** with Pydantic classes (`MeetingNotes`, `ActionItem`).
2. **Transcribe** audio with Groq's free Whisper — skipped for text files.
3. **Analyze** with `llm.with_structured_output(MeetingNotes)`, which makes the
   model fill in your data structure directly.

## Good next steps
- Add a `key_risks` field to `MeetingNotes` and watch the model start filling it in.
- Email the notes to yourself, or drop them into your notes app.
- Have it also draft follow-up messages to each action-item owner.

## Notes on free tiers
Free API limits change often, and most free tiers may train on your prompts —
keep sensitive meetings off them. If Groq is ever rate-limited (HTTP 429), you can
swap in Google's Gemini free tier by installing `langchain-google-genai` and
replacing the `ChatGroq(...)` line with a `ChatGoogleGenerativeAI(...)` line — the
rest of the code stays the same. That swap-ability is a big reason to learn
structured output the LangChain way.
