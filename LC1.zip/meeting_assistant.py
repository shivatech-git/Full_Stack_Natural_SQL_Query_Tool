"""
Meeting -> Action Items
=======================
Give this script a meeting TRANSCRIPT (.txt) or an AUDIO file (.mp3/.wav/.m4a...).
It will:
  1. Transcribe audio to text for free using Groq's Whisper (only if you gave audio).
  2. Use LangChain + Groq to extract a summary, decisions, and action items
     as CLEAN STRUCTURED DATA (not just a wall of text).
  3. Print the notes and save them to a Markdown file.

Run it:
    python meeting_assistant.py                       # uses sample_transcript.txt
    python meeting_assistant.py path/to/notes.txt     # your own transcript
    python meeting_assistant.py path/to/meeting.mp3   # your own audio
"""

import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field

# The two LangChain pieces we need:
from langchain_groq import ChatGroq                  # the model wrapper
from langchain_core.prompts import ChatPromptTemplate  # builds the prompt

# Load GROQ_API_KEY from the .env file into the environment.
load_dotenv()


# ---------------------------------------------------------------------------
# STEP 1 — Describe the SHAPE of the output we want.
#
# This is the most important idea in the whole project. Instead of asking the
# model for "a summary" and getting messy text, we define a data structure and
# tell LangChain to force the model to fill it in. These Pydantic classes ARE
# that structure. Each Field(...) description is a hint the model actually reads.
# ---------------------------------------------------------------------------
class ActionItem(BaseModel):
    """A single thing someone agreed to do."""
    task: str = Field(description="What needs to be done, phrased as a clear action.")
    owner: str = Field(description="The person responsible. Use 'Unassigned' if nobody was named.")
    due: str = Field(description="When it's due, e.g. 'Thursday'. Use 'Not specified' if none was given.")
    priority: str = Field(description="One of: high, medium, low. Infer from the discussion.")


class MeetingNotes(BaseModel):
    """The full structured summary of the meeting."""
    title: str = Field(description="A short title for the meeting.")
    summary: str = Field(description="A 2-3 sentence plain-language summary of what happened.")
    decisions: list[str] = Field(description="Concrete decisions that were finalized.")
    action_items: list[ActionItem] = Field(description="Every task someone committed to.")


# ---------------------------------------------------------------------------
# STEP 2 — Transcribe audio to text (only used if the input is an audio file).
# Uses Groq's Whisper endpoint, which is free. Text files skip this entirely.
# ---------------------------------------------------------------------------
AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".mp4", ".mpeg", ".webm", ".flac", ".ogg"}


def get_transcript(path: Path) -> str:
    """Return the meeting text, transcribing first if the file is audio."""
    if path.suffix.lower() in AUDIO_EXTENSIONS:
        print(f"Audio file detected. Transcribing with Groq Whisper: {path.name} ...")
        from groq import Groq  # imported here so text-only users don't need it

        client = Groq()  # reads GROQ_API_KEY from the environment automatically
        with open(path, "rb") as audio_file:
            result = client.audio.transcriptions.create(
                file=(path.name, audio_file.read()),
                model="whisper-large-v3",  # free, high quality; also try whisper-large-v3-turbo
            )
        return result.text

    # Otherwise it's a plain text transcript — just read it.
    return path.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# STEP 3 — Analyze the transcript with LangChain + Groq.
# ---------------------------------------------------------------------------
def analyze(transcript: str) -> MeetingNotes:
    # 3a. Create the model. llama-3.3-70b-versatile is free on Groq and handles
    #     structured output reliably. temperature=0 keeps results consistent.
    llm = ChatGroq(model="llama-3.3-70b-versatile", temperature=0)

    # 3b. .with_structured_output(MeetingNotes) is the magic line: it makes the
    #     model return a filled-in MeetingNotes object instead of loose text.
    structured_llm = llm.with_structured_output(MeetingNotes)

    # 3c. The prompt: a system message sets the role, the human message carries
    #     the transcript. "{transcript}" is a placeholder filled in at run time.
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a meticulous meeting assistant. Read the transcript and extract "
         "an accurate summary, the decisions that were finalized, and every action "
         "item with its owner, due date, and priority. Do not invent anything that "
         "was not said."),
        ("human", "Here is the meeting transcript:\n\n{transcript}"),
    ])

    # 3d. The "chain": pipe the prompt into the model. This | syntax is how
    #     LangChain connects steps together.
    chain = prompt | structured_llm

    # 3e. Run it. The result is a MeetingNotes object we can use like normal Python.
    return chain.invoke({"transcript": transcript})


# ---------------------------------------------------------------------------
# STEP 4 — Turn the structured object into a nice Markdown report.
# ---------------------------------------------------------------------------
def to_markdown(notes: MeetingNotes) -> str:
    lines = [f"# {notes.title}", "", "## Summary", notes.summary, "", "## Decisions"]
    lines += [f"- {d}" for d in notes.decisions] or ["- (none)"]
    lines += ["", "## Action Items", "", "| Task | Owner | Due | Priority |", "|---|---|---|---|"]
    for item in notes.action_items:
        lines.append(f"| {item.task} | {item.owner} | {item.due} | {item.priority} |")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Main: tie it all together.
# ---------------------------------------------------------------------------
def main() -> None:
    if not os.getenv("GROQ_API_KEY"):
        sys.exit("No GROQ_API_KEY found. Copy .env.example to .env and add your free key.")

    # Use the file path given on the command line, or fall back to the sample.
    input_path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("sample_transcript.txt")
    if not input_path.exists():
        sys.exit(f"File not found: {input_path}")

    transcript = get_transcript(input_path)
    print("Analyzing transcript with LangChain + Groq ...\n")
    notes = analyze(transcript)

    report = to_markdown(notes)
    print(report)

    out_path = input_path.with_name(input_path.stem + "_notes.md")
    out_path.write_text(report, encoding="utf-8")
    print(f"Saved notes to: {out_path}")


if __name__ == "__main__":
    main()
